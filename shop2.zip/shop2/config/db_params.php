<?php

// Массив с параметрами подключения к базе данных
return array(
    'host' => 'localhost',
    'dbname' => 'phpshop',
    'user' => 'root',
    'password' => 'root',
);
