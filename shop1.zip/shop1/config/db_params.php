<?php

return array(
    'host' => 'localhost',
    'dbname' => 'phpshop',
    'user' => 'root',
    'password' => 'root',
);
